# KasKu v4: Pencatat Uang Saku Mahasiswa

Tugas P10 Pemrograman Mobile · Prodi STI · Universitas Muhammadiyah Kotabumi
Studi kasus: SharedPreferences pada aplikasi mobile.

## Fitur
- Ringkasan sisa uang hari ini dengan progress bar dan status (aman / hampir habis / melebihi batas)
- Catat pengeluaran dengan kategori, hapus dengan tombol tempat sampah, bisa diurungkan lewat Snackbar
- Pengaturan nama, batas harian, dan tema gelap
- Ringkasan per hari dan per bulan (budget bulanan diisi sendiri, lengkap dengan rata-rata pengeluaran per hari dan saran batas per hari sampai akhir bulan)

## Pembagian data
| Data | Disimpan di | Alasan |
|---|---|---|
| Nama panggilan, batas harian, budget bulanan, tema gelap, kategori terakhir, mode tampilan hari/bulan | SharedPreferences (`PrefsManager`) | Kecil, berupa pengaturan (key-value), dibaca cepat saat aplikasi dibuka |
| Riwayat transaksi | SQLite (`DbHelper`) | Jumlah banyak, terus bertambah, perlu query, penjumlahan, dan hapus per baris |
| Sisa uang, persentase, status | Tidak disimpan | Dihitung ulang dari batas harian dikurangi total transaksi |
| Password | Tidak boleh disimpan di prefs | Rahasia |

## Cara kerja
- `PrefsManager` membungkus `SharedPreferences` (mode `MODE_PRIVATE`), data ditulis dengan `apply()`.
- `MainActivity.onResume()` memanggil `tampil()` yang membaca ulang data lewat `PrefsManager`, jadi tampilan selalu terbaru.
- Tema gelap dibaca dari prefs di `onCreate()` sebelum `super.onCreate()`.

## Cara menjalankan
Buka folder ini di Android Studio (File > Open, pilih folder yang berisi `build.gradle`), tunggu Gradle sync, lalu Run.

## Bukti data permanen
Ubah nama, batas, dan tema, lalu Info Aplikasi > Paksa Berhenti, buka lagi: pengaturan tetap ada.
